package com.test.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.RunAsyncCallback;

public class Widget11 extends Widget1 {
	
	void load( RunAsyncCallback callback ) {
		GWT.runAsync( callback );
	}

}
