package com.test.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.RootPanel;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class TestSubFragment implements EntryPoint {

	private Button showTime, showTimeCenter;
	private Widget1 w1;

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		w1 = GWT.create( Widget1.class );
		showTime = new Button("Show TIme", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				w1.show();
			}
		});
		showTimeCenter = new Button("Center TIme", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				w1.center();
			}
		});
		RootPanel.get().add(showTime);
		RootPanel.get().add(showTimeCenter);		
	}

}
