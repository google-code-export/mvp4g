package com.test.client;

import com.google.gwt.core.client.RunAsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

public abstract class Widget1 extends VerticalPanel {

	private abstract class MyRunAsyncCallback implements RunAsyncCallback {
		@Override
		public void onSuccess() {
			if ( w2 == null ) {
				w2 = new Widget2();
			}
			onRealSuccess();
		}

		@Override
		public void onFailure( Throwable reason ) {

		}

		abstract public void onRealSuccess();
	}

	private Widget2 w2;

	abstract void load( RunAsyncCallback callback );

	public Widget1() {
		add( new Label( "Widget1" ) );
	}

	public void show() {
		load( new MyRunAsyncCallback() {

			@Override
			public void onRealSuccess() {
				w2.show();
			}
		} );
	}

	public void center() {
		load( new MyRunAsyncCallback() {

			@Override
			public void onRealSuccess() {
				w2.center();
			}
		} );
	}

}
