package com.test.client;

import java.util.Date;

import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;

public class Widget2 extends PopupPanel {

	public Widget2() {
		setWidget(new Label(DateTimeFormat
				.getFormat(PredefinedFormat.TIME_FULL).format(new Date())));
	}

}
