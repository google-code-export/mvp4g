package com.mvp4g.example.client.presenter.interfaces;

import com.google.gwt.user.client.ui.IsWidget;

//for this example, our header is so simple, it does nothing ;)
//I created an header just to illustrate how layout works
public interface IHeaderView extends IsWidget {

	public interface IHeaderPresenter {

	}

}
