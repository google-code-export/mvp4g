package com.mvp4g.example.client.presenter;

import com.mvp4g.client.annotation.Presenter;
import com.mvp4g.client.presenter.LazyPresenter;
import com.mvp4g.example.client.HistoryEventBus;
import com.mvp4g.example.client.presenter.interfaces.IPage2View;
import com.mvp4g.example.client.presenter.interfaces.IPage2View.IPage2Presenter;
import com.mvp4g.example.client.view.Page2View;

@Presenter(view = Page2View.class)
public class Page2Presenter extends LazyPresenter<IPage2View, HistoryEventBus> implements IPage2Presenter {

	public void onGoToPage2(String name){
		view.setName( name );
		eventBus.setBody( view );
	}
	
}
