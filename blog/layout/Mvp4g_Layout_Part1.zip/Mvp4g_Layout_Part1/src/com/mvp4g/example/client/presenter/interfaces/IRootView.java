package com.mvp4g.example.client.presenter.interfaces;

import com.google.gwt.user.client.ui.IsWidget;

public interface IRootView extends IsWidget {

	public interface IRootPresenter {

	}
	
	void setHeader( IsWidget header );

	void setMenu( IsWidget menu );

	void setBody( IsWidget body );

	void setFooter( IsWidget footer );

}
